import flet as ft
from datetime import datetime
import os
from contract_generator import generate_contract

def main(page: ft.Page):
    page.title = "Generador de Contratos de Arrendamiento"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 0
    page.bgcolor = "#F0F4F8"
    page.fonts = {"Roboto": "https://fonts.gstatic.com/s/roboto/v32/KFOmCnqEu92Fr1Mu4mxK.woff2"}

    # ─── Color palette ───────────────────────────────────────────────
    PRIMARY    = "#1565C0"
    PRIMARY_LT = "#E3EEFA"
    ACCENT     = "#0288D1"
    SUCCESS    = "#2E7D32"
    CARD_BG    = "#FFFFFF"
    BORDER     = "#CFD8DC"
    MUTED      = "#607D8B"

    # ═══════════════════════════════════════════════════════════════
    #  STATE
    # ═══════════════════════════════════════════════════════════════
    codeudores_controls = []   # list of dicts with ft controls per codeudor
    codeudores_container = ft.Column(spacing=8)

    status_text = ft.Text("", size=14, weight=ft.FontWeight.W_500)
    status_row  = ft.Row([status_text], visible=False)

    # ═══════════════════════════════════════════════════════════════
    #  HELPERS
    # ═══════════════════════════════════════════════════════════════
    def field(label, hint="", value="", width=None, multiline=False, min_lines=1, max_lines=1):
        tf = ft.TextField(
            label=label, hint_text=hint, value=value,
            border_color=BORDER, focused_border_color=PRIMARY,
            label_style=ft.TextStyle(color=MUTED, size=13),
            text_style=ft.TextStyle(size=14),
            bgcolor=CARD_BG, border_radius=8,
            multiline=multiline, min_lines=min_lines, max_lines=max_lines,
            content_padding=ft.padding.symmetric(horizontal=14, vertical=10),
        )
        if width:
            tf.width = width
        return tf

    def section_title(text, icon=None):
        row_items = []
        if icon:
            row_items.append(ft.Icon(icon, color=PRIMARY, size=20))
            row_items.append(ft.Container(width=8))
        row_items.append(ft.Text(text, size=16, weight=ft.FontWeight.BOLD, color=PRIMARY))
        return ft.Container(
            content=ft.Column([
                ft.Row(row_items),
                ft.Divider(height=1, color=PRIMARY_LT, thickness=1.5),
            ], spacing=4),
            margin=ft.margin.only(top=8, bottom=4),
        )

    def card(content, padding=20):
        return ft.Container(
            content=content,
            bgcolor=CARD_BG,
            border_radius=12,
            padding=padding,
            border=ft.border.all(1, BORDER),
            shadow=ft.BoxShadow(blur_radius=6, color="#0D000000", offset=ft.Offset(0, 2)),
        )

    def row2(*controls):
        return ft.Row(list(controls), spacing=12, wrap=True, run_spacing=8)

    # ═══════════════════════════════════════════════════════════════
    #  FORM FIELDS
    # ═══════════════════════════════════════════════════════════════

    # ── Tipo de contrato ──────────────────────────────────────────
    tipo_contrato = ft.RadioGroup(
        content=ft.Row([
            ft.Radio(value="vivienda", label="Vivienda"),
            ft.Radio(value="local",    label="Local Comercial"),
        ]),
        value="vivienda",
    )

    # ── Datos del Arrendador ──────────────────────────────────────
    arr_nombre  = field("Nombre completo", "BEATRIZ ELENA DEJANON CLAVIJO",
                        "BEATRIZ ELENA DEJANON CLAVIJO")
    arr_cc      = field("Cédula", "42.101.938", "42.101.938", width=180)
    arr_dir     = field("Dirección física", "Carrera 10 # 12 - 43", "Carrera 10 # 12 - 43")
    arr_email1  = field("Correo electrónico 1", "correo@ejemplo.com", "cagirlon@hotmail.com")
    arr_email2  = field("Correo electrónico 2 (opcional)", "", "bettydejanon2015@hotmail.com")
    arr_cel1    = field("Celular 1", "3001234567", "3207801157", width=180)
    arr_cel2    = field("Celular 2 (opcional)", "", "3128232829", width=180)
    arr_nequi   = field("Número Nequi / Bre-B", "312-823-2829", "312-823-2829", width=220)
    arr_nequi_alias = field("Alias Nequi/Bre-B", "@alias", "@nequibea938", width=220)

    # ── Datos del Arrendatario ────────────────────────────────────
    ten_nombre  = field("Nombre completo", "JULIANA ANDREA VASQUEZ PALOMINO",
                        "JULIANA ANDREA VASQUEZ PALOMINO")
    ten_cc      = field("Cédula", "1.088.351.056", "1.088.351.056", width=200)
    ten_ciudad  = field("Ciudad de residencia", "Pereira", "Pereira", width=180)
    ten_email   = field("Correo electrónico", "correo@ejemplo.com", "julianavasquez0798@gmail.com")
    ten_cel     = field("Celular", "3136557206", "313 655 7206", width=180)

    # ── Inmueble ──────────────────────────────────────────────────
    inm_dir     = field("Dirección del inmueble", "Calle 19 # 19 - 74 Casa 2 Primer Piso",
                        "Calle 19 # 19 - 74 Casa 2 Primer Piso")
    inm_desc    = field("Descripción (Apartamento / Casa / Local...)", "Apartamento",
                        "Apartamento")

    # ── Condiciones del contrato ──────────────────────────────────
    con_fecha_contrato = field("Fecha del contrato", "17 de Marzo 2026", "17 de Marzo 2026")
    con_ciudad_contrato= field("Ciudad del contrato", "Pereira", "Pereira", width=180)
    con_duracion   = field("Duración", "seis (06) meses", "seis (06) meses", width=200)
    con_preaviso   = field("Preaviso", "dos (02) meses", "dos (02) meses", width=200)
    con_canon      = field("Canon mensual ($)", "1.150.000", "1'150.000", width=200)
    con_incremento = field("Incremento anual", "IPC", "IPC", width=180)
    con_inicio     = field("Fecha de inicio", "20 Marzo 2026", "20 Marzo 2026", width=220)
    con_fin        = field("Fecha de terminación", "20 Septiembre 2026", "20 Septiembre 2026", width=220)
    con_prorrogas  = field("Prórrogas", "Igual al periodo inicial", "Igual al periodo inicial")
    con_ciudad_domicilio = field("Domicilio contractual (ciudad)", "Cali – Valle del Cauca",
                                 "Cali – Valle del Cauca")

    # ── Checkboxes servicios públicos ─────────────────────────────
    svc_agua    = ft.Checkbox(label="Agua / Acueducto", value=True)
    svc_energia = ft.Checkbox(label="Energía", value=True)
    svc_gas     = ft.Checkbox(label="Gas", value=True)
    svc_internet= ft.Checkbox(label="Internet / Telefonía", value=False)
    svc_admin   = ft.Checkbox(label="Administración incluida en canon", value=True)

    # ── Cláusulas especiales (local comercial) ────────────────────
    local_actividad = field(
        "Actividad comercial autorizada",
        "Venta de ropa al por menor",
        multiline=True, min_lines=2, max_lines=3,
    )
    local_aviso_art = field(
        "Artículo código comercio para preaviso (ej: 518)",
        "518",
        width=180,
    )

    local_section = ft.AnimatedSwitcher(
        content=ft.Container(key="empty"),
        transition=ft.AnimatedSwitcherTransition.FADE,
        duration=250,
    )

    def update_local_section(e=None):
        if tipo_contrato.value == "local":
            local_section.content = card(ft.Column([
                section_title("Cláusulas Adicionales – Local Comercial", ft.icons.STORE),
                row2(local_actividad),
                row2(local_aviso_art),
                ft.Text(
                    "⚠️ Se activarán cláusulas de Good Will, uso de suelo y preaviso comercial.",
                    size=12, color="#E65100", italic=True,
                ),
            ], spacing=10))
        else:
            local_section.content = ft.Container(key="empty")
        page.update()

    tipo_contrato.on_change = update_local_section

    # ═══════════════════════════════════════════════════════════════
    #  CODEUDORES
    # ═══════════════════════════════════════════════════════════════
    def make_codeudor_row(index, nombre="", cc="", email="", cel=""):
        num_text = ft.Text(f"Codeudor {index+1}", size=14, weight=ft.FontWeight.W_600,
                           color=PRIMARY)
        f_nombre = field("Nombre completo", "JORGE ENRIQUE OSORNO ACOSTA", nombre)
        f_cc     = field("Cédula", "10.013.432", cc, width=180)
        f_email  = field("Correo electrónico", "correo@ejemplo.com", email)
        f_cel    = field("Celular", "311 780 4114", cel, width=180)

        def remove_self(e):
            for i, cd in enumerate(codeudores_controls):
                if cd["container"] is container:
                    codeudores_controls.pop(i)
                    break
            codeudores_container.controls.remove(container)
            # renumber
            for i2, cd2 in enumerate(codeudores_controls):
                cd2["num_text"].value = f"Codeudor {i2+1}"
            page.update()

        remove_btn = ft.IconButton(
            icon=ft.icons.REMOVE_CIRCLE_OUTLINE,
            icon_color="#C62828", tooltip="Eliminar codeudor",
            on_click=remove_self,
        )

        ctrl_dict = {"f_nombre": f_nombre, "f_cc": f_cc, "f_email": f_email,
                     "f_cel": f_cel, "num_text": num_text}

        container = card(ft.Column([
            ft.Row([num_text, ft.Container(expand=True), remove_btn]),
            row2(f_nombre, f_cc),
            row2(f_email, f_cel),
        ], spacing=8), padding=16)

        ctrl_dict["container"] = container
        return ctrl_dict

    def add_codeudor(e=None, nombre="", cc="", email="", cel=""):
        idx  = len(codeudores_controls)
        ctrl = make_codeudor_row(idx, nombre, cc, email, cel)
        codeudores_controls.append(ctrl)
        codeudores_container.controls.append(ctrl["container"])
        page.update()

    # Add default first codeudor
    add_codeudor(nombre="JORGE ENRIQUE OSORNO ACOSTA", cc="10.013.432",
                 email="jorgeenriqueosorno61@gmail.com", cel="311 7804114")

    # ═══════════════════════════════════════════════════════════════
    #  GENERATE
    # ═══════════════════════════════════════════════════════════════
    output_path_text = ft.Text("", size=13, color=SUCCESS, selectable=True)

    def collect_data():
        svcs = []
        if svc_agua.value:    svcs.append("Agua / Acueducto")
        if svc_energia.value: svcs.append("Energía")
        if svc_gas.value:     svcs.append("Gas")
        if svc_internet.value:svcs.append("Internet / Telefonía")

        cds = []
        for cd in codeudores_controls:
            cds.append({
                "nombre": cd["f_nombre"].value.strip().upper(),
                "cc":     cd["f_cc"].value.strip(),
                "email":  cd["f_email"].value.strip(),
                "cel":    cd["f_cel"].value.strip(),
            })

        return {
            "tipo": tipo_contrato.value,
            # Arrendador
            "arr_nombre":  arr_nombre.value.strip().upper(),
            "arr_cc":      arr_cc.value.strip(),
            "arr_dir":     arr_dir.value.strip(),
            "arr_email1":  arr_email1.value.strip(),
            "arr_email2":  arr_email2.value.strip(),
            "arr_cel1":    arr_cel1.value.strip(),
            "arr_cel2":    arr_cel2.value.strip(),
            "arr_nequi":   arr_nequi.value.strip(),
            "arr_nequi_alias": arr_nequi_alias.value.strip(),
            # Arrendatario
            "ten_nombre":  ten_nombre.value.strip().upper(),
            "ten_cc":      ten_cc.value.strip(),
            "ten_ciudad":  ten_ciudad.value.strip(),
            "ten_email":   ten_email.value.strip(),
            "ten_cel":     ten_cel.value.strip(),
            # Inmueble
            "inm_dir":     inm_dir.value.strip(),
            "inm_desc":    inm_desc.value.strip(),
            # Condiciones
            "fecha_contrato":    con_fecha_contrato.value.strip(),
            "ciudad_contrato":   con_ciudad_contrato.value.strip(),
            "duracion":          con_duracion.value.strip(),
            "preaviso":          con_preaviso.value.strip(),
            "canon":             con_canon.value.strip(),
            "incremento":        con_incremento.value.strip(),
            "fecha_inicio":      con_inicio.value.strip(),
            "fecha_fin":         con_fin.value.strip(),
            "prorrogas":         con_prorrogas.value.strip(),
            "ciudad_domicilio":  con_ciudad_domicilio.value.strip(),
            # Servicios
            "servicios":         svcs,
            "admin_incluida":    svc_admin.value,
            # Local comercial
            "local_actividad":   local_actividad.value.strip(),
            "local_aviso_art":   local_aviso_art.value.strip(),
            # Codeudores
            "codeudores":        cds,
        }

    def on_generate(e):
        status_row.visible = True
        status_text.value  = "⏳ Generando contrato..."
        status_text.color  = ACCENT
        output_path_text.value = ""
        page.update()

        try:
            data    = collect_data()
            outpath = generate_contract(data)
            status_text.value  = "✅ Contrato generado exitosamente"
            status_text.color  = SUCCESS
            output_path_text.value = f"📄 Guardado en: {outpath}"
        except Exception as ex:
            status_text.value = f"❌ Error: {ex}"
            status_text.color = "#C62828"

        page.update()

    # ═══════════════════════════════════════════════════════════════
    #  UI LAYOUT
    # ═══════════════════════════════════════════════════════════════

    generate_btn = ft.ElevatedButton(
        text="Generar Contrato (.docx)",
        icon=ft.icons.DESCRIPTION,
        on_click=on_generate,
        style=ft.ButtonStyle(
            bgcolor=PRIMARY, color=ft.colors.WHITE,
            padding=ft.padding.symmetric(horizontal=32, vertical=14),
            shape=ft.RoundedRectangleBorder(radius=10),
            elevation=4,
        ),
        height=52,
    )

    header = ft.Container(
        content=ft.Row([
            ft.Icon(ft.icons.ARTICLE_OUTLINED, color=ft.colors.WHITE, size=28),
            ft.Container(width=10),
            ft.Column([
                ft.Text("Generador de Contratos", size=20, weight=ft.FontWeight.BOLD,
                        color=ft.colors.WHITE),
                ft.Text("Arrendamiento de Inmueble · Colombia", size=13,
                        color="#BBDEFB"),
            ], spacing=2),
        ]),
        bgcolor=PRIMARY, padding=ft.padding.symmetric(horizontal=28, vertical=18),
    )

    form_content = ft.Column([
        # Tipo
        card(ft.Column([
            section_title("Tipo de Contrato", ft.icons.HOME_WORK),
            ft.Row([
                ft.Text("Destinación:", size=14, color=MUTED),
                tipo_contrato,
            ], spacing=12),
        ], spacing=10)),

        # Condiciones generales
        card(ft.Column([
            section_title("Condiciones del Contrato", ft.icons.ASSIGNMENT),
            row2(con_fecha_contrato, con_ciudad_contrato),
            row2(con_duracion, con_preaviso),
            row2(con_canon, con_incremento),
            row2(con_inicio, con_fin),
            row2(con_prorrogas, con_ciudad_domicilio),
        ], spacing=10)),

        # Inmueble
        card(ft.Column([
            section_title("Inmueble", ft.icons.LOCATION_ON),
            row2(inm_dir, inm_desc),
        ], spacing=10)),

        # Arrendador
        card(ft.Column([
            section_title("Arrendador", ft.icons.PERSON),
            row2(arr_nombre, arr_cc),
            row2(arr_dir, arr_email1, arr_email2),
            row2(arr_cel1, arr_cel2),
            row2(arr_nequi, arr_nequi_alias),
        ], spacing=10)),

        # Arrendatario
        card(ft.Column([
            section_title("Arrendatario", ft.icons.PERSON_OUTLINE),
            row2(ten_nombre, ten_cc, ten_ciudad),
            row2(ten_email, ten_cel),
        ], spacing=10)),

        # Servicios públicos
        card(ft.Column([
            section_title("Servicios a Cargo del Arrendador", ft.icons.BOLT),
            ft.Text("Marque los servicios que el arrendador pagará:", size=13, color=MUTED),
            ft.Row([svc_agua, svc_energia, svc_gas, svc_internet, svc_admin], wrap=True, spacing=12),
        ], spacing=10)),

        # Local comercial (dinámico)
        local_section,

        # Codeudores
        card(ft.Column([
            section_title("Codeudores", ft.icons.PEOPLE),
            codeudores_container,
            ft.Container(height=4),
            ft.OutlinedButton(
                text="+ Agregar Codeudor",
                icon=ft.icons.PERSON_ADD,
                on_click=add_codeudor,
                style=ft.ButtonStyle(
                    color=PRIMARY, side=ft.BorderSide(1.5, PRIMARY),
                    shape=ft.RoundedRectangleBorder(radius=8),
                ),
            ),
        ], spacing=10)),

        # Botón generar
        ft.Container(height=8),
        ft.Row([generate_btn], alignment=ft.MainAxisAlignment.CENTER),
        ft.Container(height=4),
        ft.Row([status_row], alignment=ft.MainAxisAlignment.CENTER),
        ft.Row([output_path_text], alignment=ft.MainAxisAlignment.CENTER),
        ft.Container(height=20),
    ], spacing=16, scroll=ft.ScrollMode.AUTO)

    main_scroll = ft.Column([
        header,
        ft.Container(
            content=ft.Container(
                content=form_content,
                max_width=860,
            ),
            padding=ft.padding.symmetric(horizontal=24, vertical=20),
            expand=True,
        ),
    ], expand=True, scroll=ft.ScrollMode.AUTO)

    page.add(main_scroll)


ft.app(target=main)
