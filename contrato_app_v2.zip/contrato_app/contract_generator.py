"""
contract_generator.py
Genera un contrato de arrendamiento .docx a partir de un diccionario de datos.
Usa python-docx (pip install python-docx).
"""

from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import os
from datetime import datetime


# ─────────────────────────────────────────────
#  STYLE HELPERS
# ─────────────────────────────────────────────

def _set_run_font(run, bold=False, size=10, color=None):
    run.bold = bold
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor(*color)


def _paragraph_spacing(para, before=0, after=4, line=None):
    from docx.oxml.ns import qn
    pPr = para._p.get_or_add_pPr()
    spacing = OxmlElement("w:spacing")
    spacing.set(qn("w:before"), str(before))
    spacing.set(qn("w:after"), str(after))
    if line:
        spacing.set(qn("w:line"), str(line))
        spacing.set(qn("w:lineRule"), "auto")
    pPr.append(spacing)


def _set_col_width(table, col_idx, width_cm):
    for row in table.rows:
        row.cells[col_idx].width = Cm(width_cm)


def _shade_cell(cell, fill_hex):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill_hex)
    tcPr.append(shd)


# ─────────────────────────────────────────────
#  SECTION BUILDERS
# ─────────────────────────────────────────────

def _add_heading(doc, text, level=1):
    """Custom styled heading"""
    para = doc.add_paragraph()
    _paragraph_spacing(para, before=120, after=60)
    run = para.add_run(text)
    run.bold = True
    run.font.size = Pt(11 if level == 1 else 10)
    run.font.color.rgb = RGBColor(21, 101, 192)  # #1565C0
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    # bottom border
    pPr = para._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "4")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "90CAF9")
    pBdr.append(bottom)
    pPr.append(pBdr)
    return para


def _add_body(doc, text, bold_parts=None, indent=False):
    para = doc.add_paragraph()
    _paragraph_spacing(para, before=0, after=60, line=276)
    if indent:
        para.paragraph_format.left_indent = Cm(0.8)
    run = para.add_run(text)
    run.font.size = Pt(9.5)
    return para


def _add_clause(doc, number, title, body, sub_paras=None):
    """Add numbered clause with optional sub-paragraphs"""
    para = doc.add_paragraph()
    _paragraph_spacing(para, before=80, after=50, line=276)
    r_num = para.add_run(f"{number}. {title.upper()}. ")
    r_num.bold = True
    r_num.font.size = Pt(9.5)
    r_body = para.add_run(body)
    r_body.font.size = Pt(9.5)

    if sub_paras:
        for sp in sub_paras:
            p = doc.add_paragraph()
            _paragraph_spacing(p, before=0, after=40, line=276)
            p.paragraph_format.left_indent = Cm(0.8)
            r = p.add_run(sp)
            r.font.size = Pt(9.5)


def _add_terms_table(doc, data):
    """Table I - Terms and conditions"""
    _add_heading(doc, "I. TÉRMINOS Y CONDICIONES DEL CONTRATO DE ARRENDAMIENTO")

    servicios_str = ", ".join(data["servicios"]) if data["servicios"] else "A cargo del arrendatario"
    if data["admin_incluida"]:
        servicios_str += " (Administración incluida en el canon)"

    rows = [
        ("1.0", "Lugar y fecha del contrato", f"{data['fecha_contrato']}, {data['ciudad_contrato']}"),
        ("1.1", "Dirección", data["inm_dir"]),
        ("1.2", "Destinación", "Vivienda" if data["tipo"] == "vivienda" else "Local Comercial"),
        ("1.3", "Duración", data["duracion"]),
        ("1.4", "Preaviso", data["preaviso"] + " a la terminación o prórrogas del contrato"),
        ("1.5", "Canon", "$ " + data["canon"]),
        ("1.6", "IVA Canon", "No Aplica" if data["tipo"] == "vivienda" else "Según normativa vigente"),
        ("1.7", "Administración", "Incluida dentro del canon" if data["admin_incluida"] else "No incluida – a cargo del arrendatario"),
        ("1.8", "IVA administración", "No Aplica"),
        ("1.9", "Incremento Anual", data["incremento"]),
        ("1.10", "Periodo de gracia", "No Aplica"),
        ("1.11", "Fecha de inicio y terminación", f"{data['fecha_inicio']} hasta {data['fecha_fin']}"),
        ("1.12", "Prórrogas", data["prorrogas"]),
        ("1.13", "Servicios Públicos", servicios_str),
        ("1.14", "Descripción del Inmueble", data["inm_desc"]),
    ]

    tbl = doc.add_table(rows=len(rows) + 1, cols=3)
    tbl.style = "Table Grid"

    # Header row
    hdr = tbl.rows[0]
    for i, txt in enumerate(["Numeral", "Ítem", "Descripción"]):
        cell = hdr.cells[i]
        _shade_cell(cell, "1565C0")
        p = cell.paragraphs[0]
        r = p.add_run(txt)
        r.bold = True
        r.font.size = Pt(9)
        r.font.color.rgb = RGBColor(255, 255, 255)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Data rows
    for idx, (num, item, desc) in enumerate(rows):
        row = tbl.rows[idx + 1]
        fill = "EFF6FF" if idx % 2 == 0 else "FFFFFF"
        for ci, val in enumerate([num, item, desc]):
            cell = row.cells[ci]
            _shade_cell(cell, fill)
            p = cell.paragraphs[0]
            r = p.add_run(val)
            r.font.size = Pt(9)
        row.cells[0].width = Cm(1.8)
        row.cells[1].width = Cm(4.5)
        row.cells[2].width = Cm(10.7)

    doc.add_paragraph()


def _add_notifications_table(doc, data):
    """Table II – Notifications"""
    _add_heading(doc, "II. NOTIFICACIONES")

    def section_rows(title, rows_data):
        return [("__title__", title)] + rows_data

    all_sections = []
    # Arrendador
    all_sections += section_rows("ARRENDADOR", [
        ("Nombre", data["arr_nombre"]),
        ("Dirección Física", data["arr_dir"]),
        ("Dirección Electrónica", data["arr_email1"] + (f"\n{data['arr_email2']}" if data["arr_email2"] else "")),
        ("Teléfono Celular", data["arr_cel1"] + (f"\n{data['arr_cel2']}" if data["arr_cel2"] else "")),
    ])
    # Arrendatario
    all_sections += section_rows("ARRENDATARIO", [
        ("Nombre", data["ten_nombre"]),
        ("C.C.", data["ten_cc"]),
        ("Ciudad", data["ten_ciudad"]),
        ("Dirección Electrónica", data["ten_email"]),
        ("Teléfono Celular", data["ten_cel"]),
    ])
    # Codeudores
    for i, cd in enumerate(data["codeudores"]):
        all_sections += section_rows(f"CODEUDOR {i+1}", [
            ("Nombre", cd["nombre"]),
            ("Documento de identidad", cd["cc"]),
            ("Dirección Electrónica", cd["email"]),
            ("Teléfono Celular", cd["cel"]),
        ])

    tbl = doc.add_table(rows=len(all_sections), cols=2)
    tbl.style = "Table Grid"

    for idx, entry in enumerate(all_sections):
        row = tbl.rows[idx]
        if entry[0] == "__title__":
            cell = tbl.rows[idx].cells[0].merge(tbl.rows[idx].cells[1])
            _shade_cell(cell, "1565C0")
            p = cell.paragraphs[0]
            r = p.add_run(entry[1])
            r.bold = True
            r.font.size = Pt(9.5)
            r.font.color.rgb = RGBColor(255, 255, 255)
        else:
            label_cell, val_cell = row.cells[0], row.cells[1]
            _shade_cell(label_cell, "E3EEFA")
            p0 = label_cell.paragraphs[0]
            r0 = p0.add_run(entry[0])
            r0.bold = True
            r0.font.size = Pt(9)
            p1 = val_cell.paragraphs[0]
            r1 = p1.add_run(entry[1])
            r1.font.size = Pt(9)

    row.cells[0].width = Cm(4.5)
    row.cells[1].width = Cm(12.5)
    doc.add_paragraph()


def _add_clauses(doc, data):
    """All contract clauses"""
    _add_heading(doc, "CLÁUSULAS")

    tipo = data["tipo"]
    is_comercial = (tipo == "local")

    servicios_arrendador = ", ".join(data["servicios"]) if data["servicios"] else "ninguno"

    # 1. OBJETO
    _add_clause(doc, "1", "PRIMERA: OBJETO",
        f"Mediante este contrato, el ARRENDADOR concede al ARRENDATARIO el uso y goce del inmueble "
        f"ubicado en {data['inm_dir']}, en la ciudad de {data['ciudad_contrato']}. "
        f"Los linderos y demás especificaciones se anotarán en documento adjunto, el cual formará parte "
        f"integral del presente contrato.",
        ["PARÁGRAFO: EL ARRENDATARIO acepta y autoriza al ARRENDADOR para que anexe los linderos, "
         "descripciones y especificaciones generales o individuales del inmueble, declarando conocerlos "
         "y acepta que figuren en escrito separado junto con el inventario firmado por las partes."]
    )

    # 2. DESTINACIÓN
    dest_text = ("vivienda exclusivamente" if not is_comercial
                 else f"local comercial para el desarrollo de la actividad: {data['local_actividad']}")
    _add_clause(doc, "2", "SEGUNDA: DESTINACIÓN",
        f"EL ARRENDATARIO se compromete a utilizar el bien arrendado para {dest_text}, "
        f"quedando prohibido cualquier otro uso sin autorización escrita del ARRENDADOR.")

    # 3. PRECIO
    _add_clause(doc, "3", "TERCERA: PRECIO",
        f"El precio mensual del canon de arrendamiento es la suma de ${data['canon']} "
        f"({'más IVA según normativa' if is_comercial else 'No aplica IVA'}). "
        f"La administración {'está incluida dentro del canon.' if data['admin_incluida'] else 'NO está incluida en el canon y será pagada por separado.'}")

    # 4. PAGO
    _add_clause(doc, "4", "CUARTA: ADMINISTRACIÓN",
        "EL ARRENDATARIO asumirá el valor de la cuota ordinaria de administración de la propiedad "
        "horizontal (si aplica), el cual será pagado mensualmente al ARRENDADOR junto con el canon.",
        ["PARÁGRAFO PRIMERO: Los incrementos que la asamblea general apruebe respecto a la cuota de "
         "administración serán asumidos por EL ARRENDATARIO.",
         "PARÁGRAFO SEGUNDO: En caso de que la copropiedad reduzca el valor de la cuota de administración, "
         "dicha reducción se trasladará automáticamente al canon de arrendamiento."]
    )

    # 5. OPORTUNIDAD Y PAGO
    _add_clause(doc, "5", "QUINTA: OPORTUNIDAD Y PAGO",
        f"El canon de arrendamiento deberá pagarse anticipadamente y a más tardar el día cinco (5) de "
        f"cada período mensual a nombre del ARRENDADOR, mediante pago por transferencia o consignación al "
        f"NEQUI {data['arr_nequi']}, Alias Bre-B: {data['arr_nequi_alias']}.",
        ["PARÁGRAFO PRIMERO: El canon de arrendamiento es indivisible; su valor no podrá ser pagado en fracciones.",
         "PARÁGRAFO SEGUNDO: El arrendatario asume el costo de la comisión cobrada por la entidad financiera.",
         "PARÁGRAFO TERCERO: La ausencia o retardo en la facturación no exime al ARRENDATARIO de efectuar "
         "el pago en los términos del contrato."]
    )

    # 6. MORA
    _add_clause(doc, "6", "SEXTA: MORA EN EL PAGO",
        "Si EL ARRENDATARIO no paga el precio del canon dentro del término estipulado, EL ARRENDADOR "
        "está autorizado para realizar el cobro de sanción por pago extemporáneo y honorarios de cobranza.",
        ["PARÁGRAFO PRIMERO: La tolerancia del ARRENDADOR en aceptar el pago con posterioridad a la "
         "fecha establecida no se entenderá como modificación de las condiciones contractuales.",
         "PARÁGRAFO SEGUNDO: Los pagos se imputarán primero a intereses corrientes o moratorios y "
         "el saldo a capital.",
         f"PARÁGRAFO TERCERO: El soporte del pago debe remitirse vía WhatsApp al número "
         f"{data['arr_cel2'] or data['arr_cel1']}."]
    )

    # 7. REAJUSTE
    _add_clause(doc, "7", "SÉPTIMA: REAJUSTE",
        f"Vencido el primer año de vigencia y así sucesivamente cada doce (12) meses, el precio anual "
        f"de la renta se incrementará conforme a las disposiciones legales vigentes. En caso de no existir "
        f"disposición legal expresa, el incremento será del {data['incremento']}.")

    # 8. TERMINACIÓN / PREAVISO
    preaviso_extra = ""
    if is_comercial:
        preaviso_extra = (f" Para destinación comercial, el preaviso se regirá por los artículos "
                          f"{data['local_aviso_art']} y siguientes del Código de Comercio.")
    _add_clause(doc, "8", "OCTAVA: NOTIFICACIÓN PARA LA TERMINACIÓN",
        f"En caso de que no se desee prorrogar el presente contrato, cualquiera de las partes deberá "
        f"notificar a la otra por escrito mediante correo certificado con una anticipación de "
        f"{data['preaviso']} a la fecha de vencimiento.{preaviso_extra}",
        ["PARÁGRAFO: Si no existe manifestación escrita de terminación, la prórroga del presente "
         "contrato se entenderá de forma automática."]
    )

    # 9. ENTREGA
    _add_clause(doc, "9", "NOVENA: ENTREGA",
        "EL ARRENDATARIO declara haber recibido el inmueble con todas sus instalaciones en buen estado, "
        "conforme al inventario anexo. Al finalizar el contrato debe hacer entrega en las mismas condiciones "
        "(resanado y pintado del mismo color en que fue entregado).")

    # 10. TÉRMINO
    _add_clause(doc, "10", "DÉCIMA: TÉRMINO",
        f"El término de duración del contrato es de {data['duracion']}, que comienza a contarse a partir "
        f"del {data['fecha_inicio']} hasta el {data['fecha_fin']}.")

    # 11. OBLIGACIONES ARRENDADOR
    _add_clause(doc, "11", "DÉCIMA PRIMERA: OBLIGACIONES DEL ARRENDADOR",
        "Son obligaciones del ARRENDADOR:",
        ["1) Entregar al ARRENDATARIO el bien inmueble arrendado en buen estado.",
         "2) Mantener el inmueble en estado de servir para el fin arrendado.",
         "3) Hacer por su cuenta las reparaciones necesarias que EL ARRENDATARIO solicite oportunamente.",
         "4) Recibir el inmueble al momento de la terminación del contrato.",
         "5) Las demás que se deriven del presente contrato o de la ley."]
    )

    # 12. OBLIGACIONES ARRENDATARIO
    _add_clause(doc, "12", "DÉCIMA SEGUNDA: OBLIGACIONES DEL ARRENDATARIO",
        "Son obligaciones del ARRENDATARIO:",
        ["a) Pagar el precio convenido dentro del término pactado.",
         "b) No entregar dinero en efectivo al personal del ARRENDADOR.",
         "c) Usar el bien arrendado exclusivamente para el uso previsto.",
         "d) Restituir el inmueble al ARRENDADOR cuando termine el contrato en las mismas condiciones.",
         "e) Remitir soporte de pago vía WhatsApp al número indicado.",
         f"f) {'Pagar los servicios públicos no incluidos en el contrato.' if data['servicios'] else 'Pagar todos los servicios públicos domiciliarios.'}",
         "g) Permitir visitas del ARRENDADOR previo aviso para verificar el estado de conservación.",
         "h) Cubrir los cánones y demás obligaciones hasta que EL ARRENDADOR reciba el inmueble."]
    )

    # 13. PROHIBICIONES
    _add_clause(doc, "13", "DÉCIMA TERCERA: PROHIBICIONES ESPECIALES",
        "Queda prohibido al ARRENDATARIO:",
        ["1) Subarrendar total o parcialmente el inmueble.",
         "2) Efectuar mejoras o reparaciones no locativas sin autorización escrita del ARRENDADOR.",
         "3) Utilizar la fachada exterior para avisos publicitarios sin autorización escrita.",
         "4) Ceder este contrato sin previa autorización del ARRENDADOR.",
         "5) Modificar la destinación pactada sin autorización del ARRENDADOR."]
    )

    # 14. SERVICIOS PÚBLICOS
    if data["servicios"]:
        svc_arrendador = ", ".join(data["servicios"])
        svc_body = (f"El pago de {svc_arrendador} corresponde al ARRENDADOR conforme a lo pactado. "
                    f"Los demás servicios son a cargo del ARRENDATARIO.")
    else:
        svc_body = ("El pago de los servicios públicos domiciliarios de energía eléctrica, gas, acueducto "
                    "y alcantarillado corresponde al ARRENDATARIO.")
    _add_clause(doc, "14", "DÉCIMA CUARTA: SERVICIOS PÚBLICOS", svc_body,
        ["PARÁGRAFO: EL ARRENDATARIO no podrá realizar ningún tipo de financiación de saldos de servicios "
         "públicos ante las empresas prestadoras sin autorización escrita del ARRENDADOR.",
         "PARÁGRAFO: EL ARRENDATARIO se obliga a pagar sanciones o multas de las empresas de servicios "
         "públicos causadas durante la vigencia del contrato."]
    )

    # 15. CLÁUSULA PENAL
    _add_clause(doc, "15", "DÉCIMA QUINTA: CLÁUSULA PENAL",
        "El incumplimiento de EL ARRENDATARIO de cualquiera de las obligaciones establecidas, o el simple "
        "retardo en el pago de uno o más cánones, lo constituirá en deudor del ARRENDADOR por una suma "
        "equivalente a tres (3) cánones vigentes de arrendamiento a título de pena.",
        ["PARÁGRAFO: El pago de la pena no extingue la obligación principal y el ARRENDADOR podrá pedir "
         "simultáneamente el pago de la pena, el cumplimiento del contrato y la indemnización de perjuicios."]
    )

    # 16. REPARACIONES
    _add_clause(doc, "16", "DÉCIMA SEXTA: REPARACIONES",
        "Las reparaciones locativas son de cargo del ARRENDATARIO. Las reparaciones necesarias no locativas "
        "serán de cargo del ARRENDADOR, previa notificación oportuna y por escrito.",
        ["PARÁGRAFO: No serán de cargo del ARRENDADOR las reparaciones necesarias por culpa del "
         "ARRENDATARIO, sus dependientes, huéspedes o familiares.",
         "PARÁGRAFO: EL ARRENDATARIO no podrá hacer mejoras ni reformas sin autorización escrita previa "
         "del ARRENDADOR."]
    )

    # 17–18. Cláusulas locales adicionales si aplica
    if is_comercial:
        _add_clause(doc, "17", "DÉCIMA SÉPTIMA: GOOD WILL",
            f"EL ARRENDATARIO no podrá pretender contra el ARRENDADOR suma alguna por conceptos de buena "
            f"clientela, acreditación del establecimiento, primas, buen nombre o 'Good Will' o similares.")
        _add_clause(doc, "18", "DÉCIMA OCTAVA: USO DEL SUELO",
            f"EL ARRENDATARIO manifiesta que la reglamentación del uso del suelo que regula la zona donde "
            f"se ubica el inmueble permite el funcionamiento de establecimientos de comercio de la naturaleza "
            f"del que es titular. EL ARRENDATARIO libera al ARRENDADOR de cualquier responsabilidad por "
            f"problemas relacionados con la naturaleza del establecimiento.")
        clause_offset = 2
    else:
        clause_offset = 0

    # Terminación (causales)
    n = 17 + clause_offset
    _add_clause(doc, n, f"{'DÉCIMA SÉPTIMA' if n==17 else 'DÉCIMA NOVENA'}: CAUSALES DE TERMINACIÓN",
        "El ARRENDADOR podrá dar por terminado el contrato por las siguientes causales:",
        ["1) Cuando el no pago de servicios públicos cause la suspensión o pérdida del servicio.",
         "2) Cuando se subarriende total o parcialmente o se dé una destinación distinta a la pactada.",
         "3) Cuando EL ARRENDATARIO realice mejoras, adiciones o cambios sin autorización.",
         "4) Cuando incumpla las normas del reglamento de propiedad horizontal.",
         "5) Cuando no realice el pago oportuno del canon y administración.",
         "6) Por la venta o permuta del bien inmueble.",
         "7) Por lavado de activos, financiación del terrorismo o inclusión en listas OFAC/ONU."]
    )

    # Mérito ejecutivo
    n += 1
    _add_clause(doc, n, f"{'DÉCIMA OCTAVA' if n==18 else 'VIGÉSIMA'}: MÉRITO EJECUTIVO",
        "El presente contrato, junto con los documentos que en él se mencionan, prestan mérito ejecutivo "
        "para exigir el pago de cánones adeudados, servicios públicos, cuotas de administración, sanciones, "
        "intereses y cualquier otra suma a cargo del ARRENDATARIO.")

    # Autorización datos personales
    n += 1
    _add_clause(doc, n, f"{'DÉCIMA NOVENA' if n==19 else 'VIGÉSIMA PRIMERA'}: AUTORIZACIÓN DE DATOS PERSONALES",
        "EL ARRENDATARIO y los DEUDORES SOLIDARIOS autorizan de manera previa, expresa e irrevocable al "
        "ARRENDADOR para consultar, solicitar, suministrar, reportar y divulgar su información ante CIFIN, "
        "DATACRÉDITO y demás bancos de datos del país, conforme a la Ley 1581 de 2012.")

    # Domicilio contractual
    n += 1
    _add_clause(doc, n, f"VIGÉSIMA: DOMICILIO CONTRACTUAL",
        f"Para efectos contractuales se tendrá como domicilio la ciudad de {data['ciudad_domicilio']}.")

    # LAVADO DE ACTIVOS
    n += 1
    _add_clause(doc, n, f"VIGÉSIMA PRIMERA: PREVENCIÓN LAVADO DE ACTIVOS",
        "Las partes se obligan a implementar medidas tendientes a evitar que las operaciones derivadas "
        "del presente contrato puedan ser utilizadas como instrumentos para el lavado de activos o la "
        "financiación del terrorismo. Cualquiera de las partes podrá dar por terminado el contrato "
        "unilateralmente si la otra es condenada o incluida en listas OFAC/ONU relacionadas con dichas "
        "actividades.")

    # MODIFICACIONES
    n += 1
    _add_clause(doc, n, f"VIGÉSIMA SEGUNDA: MODIFICACIONES",
        "Cualquier modificación al presente contrato deberá constar en escrito firmado por los "
        "representantes legales de las partes.")


def _add_signatures(doc, data):
    """Signature blocks"""
    _add_heading(doc, "FIRMAS")
    doc.add_paragraph()

    def sig_block(title, nombre, cc, extra_label=None, extra_val=None):
        p = doc.add_paragraph()
        r = p.add_run(title)
        r.bold = True
        r.font.size = Pt(10)
        r.font.color.rgb = RGBColor(21, 101, 192)

        _add_body(doc, f"NOMBRE: {nombre}")
        _add_body(doc, f"C.C. No. {cc}")
        if extra_label:
            _add_body(doc, f"{extra_label}: {extra_val}")

        line_para = doc.add_paragraph()
        _paragraph_spacing(line_para, before=20, after=80)
        r_line = line_para.add_run("Firma: _______________________________________________")
        r_line.font.size = Pt(10)
        doc.add_paragraph()

    sig_block("EL ARRENDADOR:", data["arr_nombre"], data["arr_cc"])
    sig_block("EL ARRENDATARIO:", data["ten_nombre"], data["ten_cc"])

    for i, cd in enumerate(data["codeudores"]):
        sig_block(f"CODEUDOR {i+1}:", cd["nombre"], cd["cc"])


# ─────────────────────────────────────────────
#  DOCUMENT ASSEMBLY
# ─────────────────────────────────────────────

def generate_contract(data: dict) -> str:
    """
    Generate a Word contract from the data dictionary.
    Returns the path to the saved .docx file.
    """
    doc = Document()

    # ── Page margins ──────────────────────────────────────────────
    for section in doc.sections:
        section.page_width  = int(21 * 914400 / 25.4)   # A4 width in EMUs
        section.page_height = int(29.7 * 914400 / 25.4)
        section.left_margin   = Cm(2.5)
        section.right_margin  = Cm(2.5)
        section.top_margin    = Cm(2.5)
        section.bottom_margin = Cm(2.5)

    # ── Default paragraph style ───────────────────────────────────
    style = doc.styles["Normal"]
    style.font.name = "Arial"
    style.font.size = Pt(9.5)

    # ── Cover / Title ─────────────────────────────────────────────
    title_para = doc.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _paragraph_spacing(title_para, before=0, after=80)
    r = title_para.add_run("CONTRATO DE ARRENDAMIENTO DE INMUEBLE")
    r.bold = True
    r.font.size = Pt(13)
    r.font.color.rgb = RGBColor(21, 101, 192)

    # Intro paragraph
    tipo_str = "vivienda" if data["tipo"] == "vivienda" else "local comercial"
    intro = doc.add_paragraph()
    _paragraph_spacing(intro, before=0, after=80, line=276)
    r = intro.add_run(
        f"Entre los suscritos a saber, de una parte, "
    )
    r.font.size = Pt(9.5)
    r2 = intro.add_run(data["arr_nombre"])
    r2.bold = True
    r2.font.size = Pt(9.5)
    r3 = intro.add_run(
        f", mayor de edad, identificada con Cédula Colombiana No. {data['arr_cc']}, "
        f"quien en adelante se denominará EL ARRENDADOR, de una parte; y de la otra, "
    )
    r3.font.size = Pt(9.5)
    r4 = intro.add_run(data["ten_nombre"])
    r4.bold = True
    r4.font.size = Pt(9.5)
    r5 = intro.add_run(
        f", mayor de edad, domiciliado(a) y residente en la ciudad de {data['ten_ciudad']}, "
        f"identificado(a) con cédula de ciudadanía No. {data['ten_cc']}, "
        f"quien en adelante se denominará EL ARRENDATARIO; se ha celebrado el presente contrato "
        f"de arrendamiento de {tipo_str}, el cual se regirá por las siguientes cláusulas y, "
        f"en lo no contenido en ellas, por la legislación colombiana aplicable durante su vigencia "
        f"y posteriores prórrogas contractuales."
    )
    r5.font.size = Pt(9.5)

    doc.add_paragraph()

    # ── Tables ────────────────────────────────────────────────────
    _add_terms_table(doc, data)
    _add_notifications_table(doc, data)

    # ── Clauses ───────────────────────────────────────────────────
    _add_clauses(doc, data)

    # ── Signatures ────────────────────────────────────────────────
    _add_signatures(doc, data)

    # ── Save ──────────────────────────────────────────────────────
    out_dir = os.path.join(os.path.dirname(__file__), "output")
    os.makedirs(out_dir, exist_ok=True)

    ten_safe = "".join(c for c in data["ten_nombre"].split()[0] if c.isalnum())
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename  = f"Contrato_{ten_safe}_{timestamp}.docx"
    filepath  = os.path.join(out_dir, filename)

    doc.save(filepath)
    return filepath
