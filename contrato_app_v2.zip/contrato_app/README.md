# 📄 Generador de Contratos de Arrendamiento

Aplicación de escritorio construida con **Flet** + **python-docx** para
generar contratos de arrendamiento en formato `.docx` de forma visual e
intuitiva.

---

## ✨ Características

| Función | Descripción |
|---|---|
| **Tipo de contrato** | Vivienda o Local Comercial (cambia cláusulas automáticamente) |
| **Partes** | Arrendador, Arrendatario y **N codeudores** (agregar / eliminar dinámicamente) |
| **Servicios públicos** | Checkboxes para indicar cuáles asume el arrendador |
| **Condiciones** | Canon, duración, preaviso, fechas, prórroga, incremento, domicilio |
| **Cláusulas especiales** | Good Will, uso de suelo y preaviso comercial (solo para local) |
| **Salida** | Archivo `.docx` listo para imprimir en carpeta `output/` |

---

## 🚀 Instalación

```bash
# 1. Clonar / descomprimir el proyecto
cd contrato_app

# 2. (Opcional) Crear entorno virtual
python -m venv venv
source venv/bin/activate   # Linux/Mac
venv\Scripts\activate      # Windows

# 3. Instalar dependencias
pip install -r requirements.txt
```

---

## ▶️ Uso

```bash
python main.py
```

Se abrirá una ventana de escritorio con el formulario.

### Flujo básico

1. Seleccionar **tipo de contrato** (Vivienda / Local Comercial).
2. Completar las secciones del formulario:
   - Condiciones generales (canon, fechas, duración…)
   - Datos del inmueble
   - Datos del Arrendador
   - Datos del Arrendatario
   - Servicios públicos a cargo del Arrendador
   - Codeudores (botón **"+ Agregar Codeudor"** para más de uno)
3. Pulsar **"Generar Contrato (.docx)"**.
4. El archivo se guarda en `contrato_app/output/Contrato_NOMBRE_FECHA.docx`.

---

## 📁 Estructura del proyecto

```
contrato_app/
├── main.py                # Interfaz Flet
├── contract_generator.py  # Generación del .docx
├── requirements.txt
├── README.md
└── output/                # Contratos generados (se crea automáticamente)
```

---

## 🛠️ Personalización

### Agregar nuevas cláusulas
Editar la función `_add_clauses()` en `contract_generator.py`.

### Cambiar el logotipo / encabezado
Modificar la sección "Cover / Title" en `generate_contract()`.

### Agregar nuevos campos al formulario
1. Crear el `ft.TextField` en `main.py`.
2. Incluirlo en el dict dentro de `collect_data()`.
3. Usarlo en `contract_generator.py`.

---

## 📋 Requisitos del sistema

- Python 3.9+
- Sistema operativo: Windows / macOS / Linux
- Flet 0.21+ (incluye motor Flutter integrado)

---

## 📝 Notas legales

Los textos de las cláusulas son un **modelo de referencia** basado en
contratos colombianos. Se recomienda revisar con un abogado antes de usar
en operaciones reales.
